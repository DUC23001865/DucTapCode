package hus.oop.lab1;

import java.util.Scanner;

public class PensionContributionCalculator {
    public static void main(String[] args) {

    }
}

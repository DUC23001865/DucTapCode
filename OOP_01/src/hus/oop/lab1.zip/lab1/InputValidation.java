package hus.oop.lab1;

public class InputValidation {
}
